const http = require("http");
const fs = require("fs");
const path = require("path");

const PORT = 3000;
const DATA_FILE = path.join(__dirname, "data.json");

// какие файлы сервер отдаёт браузеру 
const STATIC = {
    "/":          { file: "index.html", type: "text/html; charset=utf-8" },
    "/index.html":{ file: "index.html", type: "text/html; charset=utf-8" },
    "/style.css": { file: "style.css",  type: "text/css; charset=utf-8" },
    "/app.js":    { file: "app.js",     type: "text/javascript; charset=utf-8" }
};

function sendJSON(res, status, payload) {
    res.writeHead(status, { "Content-Type": "application/json; charset=utf-8" });
    res.end(JSON.stringify(payload));
}

function sendFile(res, fileName, contentType) {
    fs.readFile(path.join(__dirname, fileName), function (err, content) {
        if (err) {
            res.writeHead(404, { "Content-Type": "text/plain; charset=utf-8" });
            res.end("Файл не найден");
            return;
        }
        res.writeHead(200, { "Content-Type": contentType });
        res.end(content);
    });
}

function readItems(callback) {
    fs.readFile(DATA_FILE, "utf8", function (err, text) {
        if (err) { callback(err, null); return; }
        try { callback(null, JSON.parse(text)); }
        catch (parseError) { callback(parseError, null); }
    });
}

function writeItems(items, callback) {
    fs.writeFile(DATA_FILE, JSON.stringify(items, null, 2), "utf8", callback);
}

function readBody(req, callback) {
    let body = "";
    req.on("data", function (chunk) { body += chunk; });
    req.on("end", function () {
        try { callback(null, JSON.parse(body)); }
        catch (err) { callback(err, null); }
    });
}

// проверка обязательных полей
const REQUIRED = {
    title:    "строка, название на русском",
    titleEn:  "строка, оригинальное название",
    year:     "целое число",
    genre:    "строка, жанр",
    director: "строка, режиссёр",
    duration: "целое число минут, больше нуля",
    released: "true или false"
};

function validate(item) {
    const problems = [];

    for (const field in REQUIRED) {
        if (!(field in item)) {
            problems.push(`Отсутствует поле ${field}: ${REQUIRED[field]}`);
        }
    }
    if (problems.length > 0) {
        return problems;
    }

    if (typeof item.title !== "string" || item.title.trim() === "") {
        problems.push("Поле title должно быть непустой строкой");
    }
    if (typeof item.titleEn !== "string" || item.titleEn.trim() === "") {
        problems.push("Поле titleEn должно быть непустой строкой");
    }
    if (typeof item.genre !== "string" || item.genre.trim() === "") {
        problems.push("Поле genre должно быть непустой строкой");
    }
    if (typeof item.director !== "string" || item.director.trim() === "") {
        problems.push("Поле director должно быть непустой строкой");
    }
    if (!Number.isInteger(item.year) || item.year < 1900 || item.year > 2100) {
        problems.push("Поле year должно быть целым числом от 1900 до 2100");
    }
    if (!Number.isInteger(item.duration) || item.duration <= 0) {
        problems.push("Поле duration должно быть целым числом больше нуля");
    }
    if (typeof item.released !== "boolean") {
        problems.push("Поле released должно быть true или false");
    }

    return problems;
}

const server = http.createServer(function (req, res) {
    const url = new URL(req.url, `http://${req.headers.host}`);

    // 1. файлы страницы
    const staticFile = STATIC[url.pathname];
    if (staticFile) {
        sendFile(res, staticFile.file, staticFile.type);
        return;
    }

    // 2. добавление записи
    if (url.pathname === "/items" && req.method === "POST") {
        readBody(req, function (err, newItem) {
            if (err || !newItem) {
                sendJSON(res, 400, { error: "Тело запроса не является корректным JSON" });
                return;
            }

            const problems = validate(newItem);
            if (problems.length > 0) {
                sendJSON(res, 400, { error: "Данные заполнены неверно", problems: problems });
                return;
            }
            readItems(function (err2, items) {
                if (err2) { sendJSON(res, 500, { error: "Не удалось прочитать данные" }); return; }
                let maxId = 0;
                for (const item of items) {
                    if (item.id > maxId) { maxId = item.id; }
                }
                newItem.id = maxId + 1;
                items.push(newItem);
                writeItems(items, function (err3) {
                    if (err3) { sendJSON(res, 500, { error: "Не удалось сохранить" }); return; }
                    sendJSON(res, 201, newItem);
                });
            });
        });
        return;
    }

    // 3. выдача данных
    if (url.pathname === "/items") {
        readItems(function (err, items) {
            if (err) { sendJSON(res, 500, { error: "Не удалось прочитать данные" }); return; }
            const genre = url.searchParams.get("genre");
            if (genre) {
                items = items.filter(function (item) { return item.genre === genre; });
            }
            sendJSON(res, 200, items);
        });
        return;
    }

    sendJSON(res, 404, { error: "Маршрут не найден" });
});

server.listen(PORT, function () {
    console.log(`Сервер запущен: http://localhost:${PORT}`);
});


